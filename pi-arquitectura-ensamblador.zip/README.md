# Semáforo de Tránsito

Grupo: La Dinastía

Ariel Arévalo Alvarado B50562  

Cheryl Bryden Watson C01377  

Génesis Herrera Knyght C03821  

Yendry Jiménez Quesada B53675

## To Do

* Convertir este documento en un manual de usuario/créditos.
